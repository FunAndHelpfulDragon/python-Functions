import os


def check(value, _, __, **___):
    return os.path.exists(value)

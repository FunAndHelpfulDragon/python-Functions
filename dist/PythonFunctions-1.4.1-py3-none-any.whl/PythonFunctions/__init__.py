"""PythonFunctions a module for other modules
Run `python -m PythonFunctions --help` for more information
Visit `python-functions.readthedocs.io/` for the documentation
Visit `https://pypi.org/project/PythonFunctions/` for the pypi version
Visit `https://github.com/FunAndHelpfulDragon/python-Functions/tree/main/src/PythonFunctions` for the source code.
"""
